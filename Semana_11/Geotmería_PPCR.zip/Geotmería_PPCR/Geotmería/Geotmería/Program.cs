﻿using System;
using System.Collections.Generic;
using System.Deployment.Internal;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geotmería
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese el radio de su circulo");
            double radio;
            double unPerimetro = 0;
            double unArea = 0;
            double unVolumen = 0;
            radio = Convert.ToDouble(Console.ReadLine());

            Circulo miCirculo = new Circulo(radio);
            miCirculo.CalcularGeometria(ref unPerimetro, ref unArea, ref unVolumen);

            Console.WriteLine($"Perímetro: {unPerimetro}");
            Console.WriteLine($"Área: {unArea}");
            Console.WriteLine($"Volumen: {unVolumen}");
            Console.ReadKey();
        }
        
        
    }
}
