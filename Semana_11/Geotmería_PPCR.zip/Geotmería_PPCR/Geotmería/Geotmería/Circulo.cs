﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geotmería
{
    internal class Circulo
    {
        private double radio;

        public Circulo(double radio)
        {
            this.radio = radio;       
        }
        private double Obtenerperimetro()
        { 
            return 2 * Math.PI * radio;
        
        }
        private double ObtenerArea ()
        {
            return  Math.PI *Math.Pow( radio, 2);
        }
        
        private double ObtenerVolumen()
        {
            return 4/3 * Math.PI * Math.Pow( radio, 3);
        }
        public void CalcularGeometria (ref double unPerimetro, ref double unVolumen, ref double unArea) 
        {
        unPerimetro = Obtenerperimetro();
        unVolumen = ObtenerVolumen();
        unArea = ObtenerArea();
        }
    }
}
