﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace T3_PSPS1156923
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try 
            {
                Console.WriteLine("Ingrese un numero n");
                int n = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Ingrese un numero a");
                int a = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Ingrese un numero x");
                int x = Convert.ToInt32(Console.ReadLine());
                int c = 1;
                double r = 0;
                if (n > 0)
                {
                    while (c <= n)
                    {
                        r = r+(1.0 / c);
                        c = c + 1;
                    }

                    Console.WriteLine("resultado de la ecuacion 1: "+r);
                    c = 1;
                    r = 0;
                    while (c<=n)
                    {
                        r = r + (1.0 / (Math.Pow(2,c)));
                        c = c + 1;
                    }
                    Console.WriteLine("resultado de la ecuacion 2: " + r);
                    c = 0;
                    r = 0;
                    while (c<=n)
                    {
                        r = r + (Math.Pow(x, c) * Math.Pow(a, n - c));
                        c = c + 1;
                    }
                    Console.WriteLine("resultado de la ecuacion 3: " + r);
                }   
            }
            catch
            {
                Console.WriteLine("error");
            }
            Console.ReadLine();
        }
    }
}
