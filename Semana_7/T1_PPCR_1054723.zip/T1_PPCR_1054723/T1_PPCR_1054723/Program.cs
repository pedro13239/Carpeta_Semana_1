﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T1_PPCR_1054723
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi Segundo Programa");
            Console.WriteLine("Ingrese su Nombre: ");
            string Nombre = Console.ReadLine();
            Console.WriteLine("Ingrese su Edad: ");
            int Edad = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese su Carrera: ");
            string Carrera = Console.ReadLine();
            Console.WriteLine("Ingrese su numero de Carné: ");
            int Carne = int.Parse(Console.ReadLine());

            Console.Clear();

            Console.WriteLine("Datos Ingresados: ");
            Console.WriteLine("Nombre:"+ Nombre);
            Console.WriteLine("Edad:" + Edad);
            Console.WriteLine("Carrera:" + Carrera);
            Console.WriteLine("Carné:" + Carne);

            Console.WriteLine("Soy " + Nombre + " tengo "+ Edad + " años y estudio la carrera de "+ Carrera + " Mi numero de carné es " + Carne);
            Console.ReadKey();
        }
    }
}
