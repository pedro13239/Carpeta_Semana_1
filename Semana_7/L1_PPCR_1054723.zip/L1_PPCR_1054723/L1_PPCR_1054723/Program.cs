﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1_PPCR_1054723
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola mundo soy Pedro Cossio");
            Console.ReadKey();

            /*La diferencia entre WriteLine y Write es que el Writeline escribe los carateres en una nueva linea  y 
             * el Write cuando se ejecuta escribe el texto pegado.

            */
            Console.Write("Hola mundo");
            Console.Write(" soy Pedro Cossio");
            Console.ReadKey();


            Console.WriteLine("Ingrese su Nombre: ");
            string Nombre = Console.ReadLine();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy " + Nombre);


            Console.Write("Hola mundo");
            Console.Write("soy " + Nombre);
            Console.ReadKey();

        }
    }
}
